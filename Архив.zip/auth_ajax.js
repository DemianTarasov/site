// Article FructCode.com 
$( document ).ready(function() {
    $("#btn").click(
        function(){
            sendAjaxForm('result_form', 'form', 'auth.php');
            return false; 
        }
    );
});
 
function sendAjaxForm(result_form, ajax_form, url) {
    $.ajax({
        url:     url, //url страницы (reg.php)
        type:     "POST", //метод отправки
        dataType: "html", //формат данных
        data: $("#"+ajax_form).serialize(),  // Сеарилизуем объект
        success: function(response) { //Данные отправлены успешно
            result = $.parseJSON(response);
            if(result.info == "find"){
                $('#result_form').html('Login or password entered incorrectly');
            }
            if(result.info == "count"){
                $('#result_form').html('Login and password consists of 8 characters');
            }
            if(result.info == "ok"){
                $('#result_form').html('Authorization was successful under the login: ' + result.login);
            }
        },
        error: function(response) { // Данные не отправлены
            $('#result_form').html('Error. No connection to the database');
        }
    });
}