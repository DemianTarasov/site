// Article FructCode.com 
$( document ).ready(function() {
    $("#btn").click(
        function(){
            sendAjaxForm('result_form', 'form', 'search.php');
            return false; 
        }
    );
});
 
function sendAjaxForm(result_form, ajax_form, url) {
    console.log('hi')
    $.ajax({
        url:     url, //url страницы (reg.php)
        type:     "POST", //метод отправки
        dataType: "html", //формат данных
        data: $("#"+ajax_form).serialize(),  // Сеарилизуем объект
        success: function(response) { //Данные отправлены успешно
            result = $.parseJSON(response);
            if(result.info == "ok"){
                $('#name').html(result.name + ' ' + result.surname + ' ' + result.patronymic + '<br>Login: ' + result.login + ' ID: ' + result.id);
                $('#first').html('Main module');
                $('#lastUpdate').html('Last update:<br><strong>' + result.lastUpdate + 'MSK</strong>');
                $('#memberCount').html('Сonnected module: <strong>' + result.memberCount + '</strong>');
                $('#second').html('Pedal module');
                $('#longpress').html('Last update: <strong>' + result.longpress + '</strong>');
                $('#press').html('No pressing while working: <strong>' + result.press + '</strong>');
                $('#unpress').html('Pressing while relaxing: <strong>' + result.unpress + '</strong>');
                $('#third').html('Сargo module');
                $('#temp').html('Temperature: <strong>' + result.temp + '°C</strong>');
                $('#hum').html('Humidity: <strong>' + result.hum + '%</strong>');
                $('#ogon').html('Fire: <strong>' + result.ogon + '</strong>');
                $('#potop').html('Flood: <strong>' + result.potop + '</strong>');
                $('#smoke').html('Smoke: <strong>' + result.smoke + 'ppm</strong>');   
            }  
            if(result.info == "found"){
               $('#name').html('Driver not found'); 
            }
        },
        error: function(response) { // Данные не отправлены
            $('#name').html('Error. No connection to the database');
        }
    });
}