// Article FructCode.com 
$(document).ready(function() {
    $("#btn").click(
        function() {
            sendAjaxForm('result_form', 'form', 'auth.php');
            return false;
        }
    );
});

function sendAjaxForm(result_form, ajax_form, url) {
    $.ajax({
        url: url, //url страницы (reg.php)
        type: "POST", //метод отправки
        dataType: "html", //формат данных
        data: $("#" + ajax_form).serialize(), // Сеарилизуем объект
        success: function(response) { //Данные отправлены успешно
            result = $.parseJSON(response);
            if (result.info == "find") {
                $('#result_form').html('Логин или пароль введены некоректно');
            }
            if (result.info == "count") {
                $('#result_form').html('Логин и пароль должен состоять из минимум 8 символов');
            }
            if (result.info == "ok") {
                $('#result_form').html('Авторизация прошла успешно под логином: ' + result.login);
            }
        },
        error: function(response) { // Данные не отправлены
            $('#result_form').html('Ошибка. Нет подключения к базе данных');
        }
    });
}