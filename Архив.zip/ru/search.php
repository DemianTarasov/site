<?php
ini_set('display_errors', 0);
if (isset($_POST["id"])) { 

  $id = $_POST['id'];
  $db_host = 'remotemysql.com';
  $db_user = 'aSbslCHon7';
  $db_password = '9GXRh7KVkC';
  $db_db = 'aSbslCHon7';
 
  $mysqli = @new mysqli(
    $db_host,
    $db_user,
    $db_password,
    $db_db
  );
  
  if ($mysqli->connect_error) {
    echo 'error';
    exit();
  }
  $res = $mysqli->query("SELECT * FROM `RoboSpheraTable` WHERE `id`= '$id'");
  $okres = $res->fetch_assoc();
  if($okres['login'] == NULL){
    $result = array(
      'info' => "found"
    );
  }
  else{
    $result = array(
      'info' => "ok",
      'name' => $okres['name'],
      'surname' => $okres['surname'],
      'patronymic' => $okres['patronymic'],
      'login' => $okres['login'],
      'id' => $okres['id'],
      'lastUpdate' => $okres['lastUpdate'],
      'memberCount' => $okres['memberCount'],
      'longpress' => $okres['longpress'],
      'press' => $okres['press'],
      'unpress' => $okres['unpress'],
      'temp' => $okres['temp2'],
      'hum' => $okres['hum2'],
      'ogon' => $okres['ogon2'],
      'potop' => $okres['potop2'],
      'smoke' => $okres['smoke2']
    );
  }
  echo json_encode($result); 
}
?>