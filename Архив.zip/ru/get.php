<?php
	if(isset($_GET['modul']) && isset($_GET['id'])){
		date_default_timezone_set('Europe/Moscow');
		$tupe=$_GET['modul'];
		$id=$_GET['id'];
		$db_host = 'remotemysql.com';
    	$db_user = 'aSbslCHon7';
    	$db_password = '9GXRh7KVkC';
    	$db_db = 'aSbslCHon7';
    	$mysqli = @new mysqli(
    	  $db_host,
    	  $db_user,
    	  $db_password,
    	  $db_db
    	);
    	if ($mysqli->connect_error) {
    	  echo 'not connection';
    	  exit();
    	}
		if($tupe == "2" && isset($_GET['memberCount'])){
			$memberCount=$_GET['memberCount'];
			$time=date('j \of F Y H:i:s ');
			
			$mysqli->query("UPDATE `RoboSpheraTable` SET `memberCount` = '$memberCount', `lastUpdate` = '$time' WHERE `id` = '$id'");
			echo $time;
			echo "<br>";
			echo $memberCount;
		}
		if($tupe == "1" && isset($_GET['press']) && isset($_GET['unpress']) && isset($_GET['longpress'])){
			$press = $_GET['press'];
			$unpress = $_GET['unpress'];
			$longpress = $_GET['longpress'];

			$mysqli->query("UPDATE `RoboSpheraTable` SET `press` = '$press', `unpress` = '$unpress', `longpress` = '$longpress' WHERE `id` = '$id'");
			echo $press;
			echo "<br>";
			echo $unpress;
			echo "<br>";
			echo $longpress;
		}
		if($tupe == "4" && isset($_GET['hum2']) && isset($_GET['temp2']) && isset($_GET['potop2']) && isset($_GET['ogon2']) && isset($_GET['smoke2'])){
			$hum = $_GET['hum2'];
			$temp = $_GET['temp2'];
			$fire = $_GET['ogon2'];
			$flood = $_GET['potop2'];
			$smoke = $_GET['smoke2'];

			$mysqli->query("UPDATE `RoboSpheraTable` SET `hum2` = '$hum', `temp2` = '$temp', `ogon2` = '$fire', `potop2` = '$flood', `smoke2` = '$smoke' WHERE `id` = '$id'");
			echo $temp;
			echo "<br>";
			echo $hum;
			echo "<br>";
			echo $fire;
			echo "<br>";
			echo $flood;
			echo "<br>";
			echo $smoke;
		}
		$mysqli->close();
	}





?>