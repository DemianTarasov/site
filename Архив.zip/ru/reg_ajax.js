// Article FructCode.com 
$(document).ready(function() {
    $("#btn").click(
        function() {
            sendAjaxForm('result_form', 'form', 'reg.php');
            return false;
        }
    );
});

function sendAjaxForm(result_form, ajax_form, url) {
    $.ajax({
        url: url, //url страницы (reg.php)
        type: "POST", //метод отправки
        dataType: "html", //формат данных
        data: $("#" + ajax_form).serialize(), // Сеарилизуем объект
        success: function(response) { //Данные отправлены успешно
            result = $.parseJSON(response);
            if (result.info == "ok") {
                $('#result_form').html('Регистрация прошла успешно. Ваше ID это ' + result.id);
            }
            if (result.info == "login") {
                $('#result_form').html('Логин уже занят');
            }
            if (result.info == "count") {
                $('#result_form').html('Поля ввода должны состоять из 8 символов');
            }
            if (result.info == "email") {
                $('#result_form').html('Email не соответствует требованиям');
            }
        },
        error: function(response) { // Данные не отправлены
            $('#result_form').html('Ошибка. Нет подключения к базе данных');
        }
    });
}