// Article FructCode.com 
$(document).ready(function() {
    $("#btn").click(
        function() {
            sendAjaxForm('result_form', 'form', 'search.php');
            return false;
        }
    );
});
console_log('hi');

function sendAjaxForm(result_form, ajax_form, url) {
    $.ajax({
        url: url, //url страницы (reg.php)
        type: "POST", //метод отправки
        dataType: "html", //формат данных
        data: $("#" + ajax_form).serialize(), // Сеарилизуем объект
        success: function(response) { //Данные отправлены успешно
            result = $.parseJSON(response);
            if (result.info == "ok") {
                $('#name').html(result.name + ' ' + result.surname + ' ' + result.patronymic + '<br>Логин: ' + result.login + ' ID: ' + result.id);
                $('#first').html('Главный модуль');
                $('#lastUpdate').html('Последнее обновление:<br><strong>' + result.lastUpdate + 'МСК</strong>');
                $('#memberCount').html('Подключенно модулей: <strong>' + result.memberCount + '</strong>');
                $('#second').html('Модуль на педали');
                $('#longpress').html('Долгие нажатия: <strong>' + result.longpress + '</strong>');
                $('#press').html('Ненажатий при работе: <strong>' + result.press + '</strong>');
                $('#unpress').html('Нажатия при отдыхе: <strong>' + result.unpress + '</strong>');
                $('#third').html('Модуль в кузове');
                $('#temp').html('Температура: <strong>' + result.temp + '°C</strong>');
                $('#hum').html('Влажность: <strong>' + result.hum + '%</strong>');
                $('#ogon').html('Пожар: <strong>' + result.ogon + '</strong>');
                $('#potop').html('Затопление: <strong>' + result.potop + '</strong>');
                $('#smoke').html('Задымление: <strong>' + result.smoke + 'ppm</strong>');
            }
            if (result.info == "found") {
                $('#name').html('Водитель не найден');
            }
        },
        error: function(response) { // Данные не отправлены
            $('#name').html('Ошибка. Нет соединения с базой данных');
        }
    });
}