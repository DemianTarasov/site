<?php
	ini_set('display_errors', 0);
  $login = $_COOKIE['login'];
  $db_host = 'remotemysql.com';
  $db_user = 'aSbslCHon7';
  $db_password = '9GXRh7KVkC';
  $db_db = 'aSbslCHon7';
 
  $mysqli = @new mysqli(
    $db_host,
    $db_user,
    $db_password,
    $db_db
  );
  
  if ($mysqli->connect_error) {
    echo 'error';
    exit();
  }
  else{
  $res = $mysqli->query("SELECT * FROM `RoboSpheraTable` WHERE `login`= '$login'");
  $okres = $res->fetch_assoc();
}
  if ($_COOKIE['login']==''):
    ?>
    <?php
    exit("<meta http-equiv='refresh' content='0; url= /index.php'>");
?>
<?php
else:
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/account.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<title>Driver's assistant</title>
</head>
<body>
		<!-- Header -->
	<header class="header">
		<div class="container">
			<div class="header_inner">
				<div class="header_logo">
					<a class="header_link header_link_logo" href="index.php"><strong>Driver's Assistant</strong></a>
				</div>
				<nav class="header_nav" id="nav">
					<?php if($_COOKIE['login'] == NULL):?>
						<a class="header_link" href="about.php">о нас</a>
						<a class="header_link" href="../account.php">translate</a>
					<?php else:?>
						<a class="header_link" href="about.php">о нас</a>
						<a class="header_link" href="../account.php">translate</a>
						<a class="header_link" href="account.php"><?= $_COOKIE['login']?></a>
					<?php endif;?>
				</nav>
				<button class="burger" id="showButton">
					<span class="burger_item" id="burgerCross">Menu</span>
				</button>
			</div>
		</div>
	</header>
	<!-- main -->
	<div class="main">
		<div class="container">
			<div class="main_title"><?php echo $okres['surname'];?> <?php echo $okres['name'];?> <?php echo $okres['patronymic'];?><br>Логин:<?php echo $okres['login'];?>, ID: <?php echo $okres['id'];?></div>
			<div class="main_inner">
				<div class="main_block">
					<h4 class="main_text">
						Главный модуль
					</h4>
					<p class="main_text_name">Последнее обновление:<br><strong><?php echo $okres['lastUpdate'];?></strong></p>
					<p class="main_text_name">Подключенно модулей:<strong> <?php echo $okres['memberCount'];?></strong></p>
				</div>
				<div class="main_block">
					<h4 class="main_text">
						Модуль на педали
					</h4>
					<p class="main_text_name">Долгие нажатия: <strong><?php echo $okres['longpress'];?></strong></p>
					<p class="main_text_name">Ненажатий при работе:<strong> <?php echo $okres['press'];?></strong></p>
					<p class="main_text_name">Нажатия при отдыхе:<strong> <?php echo $okres['unpress'];?></strong></p>
				</div>
				<div class="main_block">
					<h4 class="main_text">
						Модуль в кузове
					</h4>
					<p class="main_text_name">Температура: <strong><?php echo $okres['temp2'];?>°C</strong></p>
					<p class="main_text_name">Влажность:<strong> <?php echo $okres['hum2'];?>%</strong></p>
					<p class="main_text_name">Пожар:<strong> <?php echo $okres['ogon2'];?></strong></p>
					<p class="main_text_name">Затопление:<strong> <?php echo $okres['potop2'];?></strong></p>
					<p class="main_text_name">Задымление:<strong> <?php echo $okres['smoke2'];?>ppm</strong></p>
				</div>
			</div>
		</div>
	</div>
	<!-- buttons -->
	<div class="buttons">
		<div class="container">
			<div class="buttons_inner">
				<div class="buttons_block">
					<a href="change_password.php" class="buttons_link_change">Сменить пороль</a>
				</div>
				<div class="buttons_block">
					<a href="exit.php" class="buttons_link_exit">Выйти</a>
				</div>
			</div>
		</div>
	</div>

	<!-- futer -->
	<footer class="futer">
		<div class="container">
			<div class="futer_inner">
				<div class="futer_block">
					<h4 class="futer_text">
						Команда
					</h4>
					
					<p><a class="futer_text_name" href="https://vk.com/krisapip">Демьян Тарасов</a></p>
					<p><a class="futer_text_name" href="https://vk.com/id646411951">Вова Блинов</a></p>
				</div>
				<div class="futer_block">
					<h4 class="futer_text">
						Ресурсы
					</h4>

					<p><a class="futer_text_name" href="https://github.com/DemianTarasov/site">Сайт</a></p>
					<p><a class="futer_text_name" href="https://vk.com/izhdvores">Наша группа</a></p>
				</div>
			</div>
		</div>
	</footer>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>
<?php
	endif;?>