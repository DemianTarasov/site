<?php
	ini_set('display_errors', 0);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/about.css">
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<title>Driver's assistant</title>
</head>
<body>
	<!-- Header -->
	<header class="header">
		<div class="container">
			<div class="header_inner">
				<div class="header_logo">
					<a class="header_link header_link_logo" href="index.php"><strong>Driver's Assistant</strong></a>
				</div>
				<nav class="header_nav" id="nav">
					<?php if($_COOKIE['login'] == NULL):?>
						<a class="header_link" href="about.php">о нас</a>
						<a class="header_link" href="../about.php">translate</a>
					<?php else:?>
						<a class="header_link" href="about.php">о нас</a>
						<a class="header_link" href="../about.php">translate</a>
						<a class="header_link" href="account.php"><?= $_COOKIE['login']?></a>
					<?php endif;?>
				</nav>
				<button class="burger" id="showButton">
					<span class="burger_item" id="burgerCross">Menu</span>
				</button>
			</div>
		</div>
	</header>


	<!-- team -->
	<div class="team">
		<div class="container">
			<h4 class="team_title">наша команда</h4>
			<div class="team_inner">
				<div class="team_block">
					<div class="team_photo1"></div>
					<div class="team_content">
						<a class="team_name" href="https://vk.com/krisapip">Тарасов Демьян</a>

						<h4 class="team_text">Я из Ижевки, мне 13 лет. Я программист этого проекта.</h4>
					</div>
				</div>
				<div class="team_block">
					<div class="team_photo2"></div>
					<div class="team_content">
						<a class="team_name" href="https://vk.com/id646411951">Блинов Владимир</a>

						<h4 class="team_text">Я родился в городе Ижевка и мне 13 лет. Я разработал проект.</h4>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- about project -->
	<div class="project_slider">
		<div class="container">
			<h4 class="team_title">о проекте</h4>
			<div class="project_inner">
				<!-- <div class="project_block_left">
					<div class="project_slider_arrow_left"><</div>
				</div> -->
				<div class="project_block_main">
					<ul class="project_slider_list">
    		    	 	<li class="project_slider_element">
    		    	 		<div class="project_photo1"></div>
    		    	 		<div class="project_content">
    		    	 			<div class="project_title">
    		    	 				1 модуль
    		    	 			</div>
    		    	 			<div class="project_text">
    		    	 				1 модуль находится на педали газа и отправляет данные о силе и частоте нажатия на педаль на сайт и в модуль 2
    		    	 			</div>
    		    	 		</div>
    		    	 	</li>
    		    	 	<li class="project_slider_element">
    		    	 		<div class="project_photo2"></div>
    		    	 		<div class="project_content">
    		    	 			<div class="project_title">
    		    	 				2 модуль
    		    	 			</div>
    		    	 			<div class="project_text">
    		    	 				2 отслеживает все данные, отправленные другими модулями. Обрабатывает и уведомляет о некорректной работе водителя (1 модуль) и выводит данные с 3-го модуля.
    		    	 			</div>
    		    	 		</div>
    		    	 	</li>
    		    	 	<li class="project_slider_element">
    		    	 		<div class="project_photo3"></div>
    		    	 		<div class="project_content">
    		    	 			<div class="project_title">
    		    	 				3 модуль
    		    	 			</div>
    		    	 			<div class="project_text">
    		    	 				3 модуль находится рядом с грузом и следит за его состоянием. Он отправляет все данные в модуль 2 и на сайт.
    		    	 			</div>
    		    	 		</div>
    		    	 	</li>
    		 		</ul>
				</div>
				<!-- <div class="project_block_right">
					<div class="project_slider_arrow_right">></div>
				</div> -->
				<div class="project_block_left2">
					<div class="project_slider_arrow_left"><</div>
				</div>
				<div class="project_block_right2">
					<div class="project_slider_arrow_right">></div>
				</div>
			</div>
		<!-- 	<div class="project_slider">
    		 	<div class="project_block">
   					<div class="project_slider_arrow_left"><</div>
   				</div>
				<div class="project_block">
    		 		
    		 	</div>
   				<div class="project_block">
    		 		<div class="project_slider_arrow_right">></div>
    		 	</div>
 			</div> -->
 		</div>
 	</div>
	<!-- futer -->
	<footer class="futer">
		<div class="container">
			<div class="futer_inner">
				<div class="futer_block">
					<h4 class="futer_text">
						Команда
					</h4>
					
					<p><a class="futer_text_name" href="https://vk.com/krisapip">Демьян Тарасов</a></p>
					<p><a class="futer_text_name" href="https://vk.com/id646411951">Вова Блинов</a></p>
				</div>
				<div class="futer_block">
					<h4 class="futer_text">
						Ресурсы
					</h4>

					<p><a class="futer_text_name" href="https://github.com/DemianTarasov/site">Сайт</a></p>
					<p><a class="futer_text_name" href="https://vk.com/izhdvores">Наша группа</a></p>
				</div>
			</div>
		</div>
	</footer>
	<!-- Javascript -->
	<script type="text/javascript" src="js/app.js"></script>
	<script src="js/slider.js"></script>
	<!-- вызов слайдера -->
	<script>new Sim()</script>
</body>
</html>