<?php

if (isset($_POST["login"]) && isset($_POST["name"]) && isset($_POST["surname"]) && isset($_POST["patronymic"]) && isset($_POST["email"]) && isset($_POST["password"])) { 

    // Формируем массив для JSON ответа

    $db_host = 'remotemysql.com';
    $db_user = 'aSbslCHon7';
    $db_password = '9GXRh7KVkC';
    $db_db = 'aSbslCHon7';
    $mysqli = @new mysqli(
      $db_host,
      $db_user,
      $db_password,
      $db_db
    );
    if ($mysqli->connect_error) {
      echo 'Errno: '.$mysqli->connect_errno;
      echo '<br>';
      echo 'Error: '.$mysqli->connect_error;
      echo 'not connection';
      // $result = array(
      //     'info' => 'fail'
      // ); 
      exit();
    }
    else{
        $login =$_POST["login"];
        $password = $_POST["password"];
        $name = $_POST["name"];
        $surname = $_POST["surname"];
        $patronymic = $_POST["patronymic"];
        $email = $_POST["email"];
        if(strlen($login) < 8 or strlen($password) < 8){
            $result = array(
               'info' => "count"
            );
        }
        else{
            if(filter_var($email, FILTER_VALIDATE_EMAIL)){
                $mysqli->query("INSERT INTO `RoboSpheraTable` ( `login`, `email`, `password`, `name`, `surname`, `patronymic`, `press`, `unpress`, `longpress`, `temp1`, `voda1`, `eda1`, `temp2`, `hum2`, `potop2`, `ogon2`, `smoke2`, `memberCount`, `lastUpdate`) VALUES('$login', '$email', '$password', '$name','$surname', '$patronymic', '0', '0', '0', '0', '0', '0', '0', '0', '-', '-', '0', '0', '-') ");
                $res = $mysqli->query("SELECT * FROM `RoboSpheraTable` WHERE `login`= '$login' and `name`='$name'");
                $okres = $res->fetch_assoc();
                $mysqli->close();  
                setcookie('login', $okres['login'], time() + 3600, "/");
                $result = array(
                    'info' => "ok",
                    'id' =>$okres["id"]
                );
            }
            else{
                $result = array(
                    'info' => "email"
                );
            }
        }
        // Переводим массив в JSON
        
        // echo 'ok';
    }
    echo json_encode($result); 
    
}

?>