<?php
	ini_set('display_errors', 0);
	setcookie('login', $okres['login'], time() * 0, "/");
	exit("<meta http-equiv='refresh' content='0; url= /index.php'>");
?>