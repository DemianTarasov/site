<?php
ini_set('display_errors', 0);
	if ($_COOKIE['login'] != NULL) {
		exit("<meta http-equiv='refresh' content='0; url= /index.php'>");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/signin.css">
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
  	<script src="auth_ajax.js"></script>
	<title>Sign in</title>
</head>
<body>
	<script type="text/javascript">
        $('body').on('click', '.main_checkbox', function(){
            if ($(this).is(':checked')){
                $('#main_password').attr('type', 'text');
            } else {
                $('#main_password').attr('type', 'password');
            }
        });
    </script>
		<!-- Header -->
	<header class="header">
		<div class="container">
			<div class="header_inner">
				<div class="header_logo">
					<a class="header_link header_link_logo" href="index.php"><strong>Driver's Assistant</strong></a>
				</div>
				<nav class="header_nav" id="nav">
					<?php if($_COOKIE['login'] == NULL):?>
						<a class="header_link" href="about.php">about us</a>
						<a class="header_link" href="ru/signin.php">перевести</a>
					<?php else:?>
						<a class="header_link" href="about.php">about us</a>
						<a class="header_link" href="ru/signin.php">перевести</a>
						<a class="header_link" href="account.php"><?= $_COOKIE['login']?></a>
					<?php endif;?>
				</nav>
				<button class="burger" id="showButton">
					<span class="burger_item" id="burgerCross">Menu</span>
				</button>
			</div>
		</div>
	</header>
	<!-- Main -->
	<div class="main">
        <div class="blur">
		  <div class="container">
		  	<div class="main_inner">
		  		<form method="post" id="form" action="" class="main_form" style="text-align: center;">
		  				<h1 class="main_input" style="border: 0;">Authorization</h1>
                        <input class="main_input" type="text" name="login" placeholder="login"><br>
                        <input class="main_input" type="password" name="password" placeholder="password" id="main_password"><br>
                        <label class="main_l"><input type="checkbox" class="main_checkbox"> <b class="main_checkbox_text">Show password</b></label><br>
                        <input class="main_button" type="button" id="btn" value="Sign in">
		  		</form> 
                <div class="main_link"><a href="signup.php">Sign up</a></div>
                <div class="main_answer" id="result_form"></div> 
		  	</div>
		  </div>
        </div>
	</div>
	<!-- <form method="post" id="ajax_form" action="" >
        <input type="text" name="name" placeholder="NAME" /><br>
        <input type="text" name="phonenumber" placeholder="YOUR PHONE" /><br>
        <input type="button" id="btn" value="Отправить" />
    </form> -->


	<!-- futer -->
	<footer class="futer">
		<div class="container">
			<div class="futer_inner">
				<div class="futer_block">
					<h4 class="futer_text">
						in team
					</h4>
					
					<p><a class="futer_text_name" href="https://vk.com/krisapip">Demian Tarasov</a></p>
					<p><a class="futer_text_name" href="https://vk.com/id646411951">Blinov Vladimir</a></p>
				</div>
				<div class="futer_block">
					<h4 class="futer_text">
						resources
					</h4>

					<p><a class="futer_text_name" href="https://github.com/DemianTarasov/site">Website</a></p>
					<p><a class="futer_text_name" href="https://vk.com/izhdvores">Our group</a></p>
				</div>
			</div>
		</div>
	</footer>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>