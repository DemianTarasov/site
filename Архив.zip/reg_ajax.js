// Article FructCode.com 
$( document ).ready(function() {
    $("#btn").click(
        function(){
            sendAjaxForm('result_form', 'form', 'reg.php');
            return false; 
        }
    );
});
 
function sendAjaxForm(result_form, ajax_form, url) {
    $.ajax({
        url:     url, //url страницы (reg.php)
        type:     "POST", //метод отправки
        dataType: "html", //формат данных
        data: $("#"+ajax_form).serialize(),  // Сеарилизуем объект
        success: function(response) { //Данные отправлены успешно
            result = $.parseJSON(response);
            if(result.info == "ok"){
                $('#result_form').html('Registration went well. Your ID is '+result.id);
            }
            if(result.info == "login"){
                $('#result_form').html('Login is already taken');
            }
            if(result.info == "count"){
                $('#result_form').html('Fields must be 8 characters long');
            }
            if(result.info == "email"){
                $('#result_form').html('Email does not match the requirements');
            }  
        },
        error: function(response) { // Данные не отправлены
            $('#result_form').html('Error. No connection to the database');
        }
    });
}