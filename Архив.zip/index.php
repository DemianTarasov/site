<?php
	ini_set('display_errors', 0);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
	
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<title>Driver's assistant</title>
</head>
<body>  
	<script type="text/javascript" src="trans_ajax.js"></script>
	<script src="search_ajax.js"></script>
	<!-- Header -->
	<header class="header">
		<div class="container">
			<div class="header_inner">
				<div class="header_logo">
					<a class="header_link header_link_logo" href="index.php"><strong>Driver's Assistant</strong></a>
				</div>
				<nav class="header_nav" id="nav">
					<?php if($_COOKIE['login'] == NULL):?>
						<a class="header_link" href="about.php">about us</a>
						<a class="header_link" href="ru/index.php">перевести</a>
					<?php else:?>
						<a class="header_link" href="about.php">about us</a>
						<a class="header_link" href="ru/index.php">перевести</a>
						<a class="header_link" href="account.php"><?= $_COOKIE['login']?></a>
					<?php endif;?>
				</nav>
				<button class="burger" id="showButton">
					<span class="burger_item" id="burgerCross">Menu</span>
				</button>
			</div>
		</div>
	</header>
	<!-- intro -->
	<div class="intro">
		<div class="blur">
		<div class="container">
			<div class="intro_inner">
				<h1 class="intro_title">drivers's assistant</h1>
				<h1 class="intro_content">We will improve the quality of cargo transportation by trucks</h1>
			</div>
		</div>
	</div>
	</div>
	<!-- find -->
	<div class="find">
		<div class="container">
			<div class="find_inner">
				<div class="find_content">
					<div class="find_main">
						<h4 class="find_text">
							<strong>Find the driver with your cargo by his ID and find out what is happening with your package</strong>
						</h4>
						<form method="post" id="form" action="" class="find_form">
							<input type="text" name="id" class="find_input" placeholder="driver's ID"><br>
							<input type="button" id="btn" class="find_button" value="Search">
						</form>
					</div>
				</div>
				<div class="find_photo">
					<div class="find_img"></div>
				</div>
			</div>
		</div>
	</div>
	<!-- main -->
	<div class="main">
		<div class="container">
			<div id="name" class="main_title">Driver information will be displayed here</div>
			<div class="main_inner">
				<div class="main_block">
					<h4 id="first" class="main_text">
					</h4>
					<p id="lastUpdate" class="main_text_name"></p>
					<p id="memberCount" class="main_text_name"></p>
				</div>
				<div  class="main_block">
					<h4 id="second" class="main_text">
					</h4>
					<p id="longpress" class="main_text_name"></p>
					<p id="press" class="main_text_name"></p>
					<p id="unpress" class="main_text_name"></p>
				</div>
				<div  class="main_block">
					<h4 id="third" class="main_text">
					</h4>
					<p id="temp" class="main_text_name"></p>
					<p id="hum" class="main_text_name"></p>
					<p id="ogon" class="main_text_name"></p>
					<p id="potop" class="main_text_name"></p>
					<p id="smoke" class="main_text_name"></p>
				</div>
			</div>
		</div>
	</div>
	<!-- get started -->
	<div class="started">
		<div class="blur">
			<div class="container">
				<div class="started_inner">
					<h4 class="started_text">
						Become one of the drivers who use our device
					</h4>
					<div class="started_button">
						<a class="started_link" href="signup.php">
							get started
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>




	<!-- futer -->
	<footer class="futer">
		<div class="container">
			<div class="futer_inner">
				<div class="futer_block">
					<h4 class="futer_text">
						in team
					</h4>
					
					<p><a class="futer_text_name" href="https://vk.com/krisapip">Demian Tarasov</a></p>
					<p><a class="futer_text_name" href="https://vk.com/id646411951">Blinov Vladimir</a></p>
				</div>
				<div class="futer_block">
					<h4 class="futer_text">
						resources
					</h4>

					<p><a class="futer_text_name" href="https://github.com/DemianTarasov/site">Website</a></p>
					<p><a class="futer_text_name" href="https://vk.com/izhdvores">Our group</a></p>
				</div>
			</div>
		</div>
	</footer>
	<!-- Javascript -->
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>