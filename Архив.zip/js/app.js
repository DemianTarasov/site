$(function(){



	// show nav
	let nav = $("#nav");
	let cross = $("#burgerCross");
	let showButton = $("#showButton");

	showButton.on("click", function(event){
		event.preventDefault();

		nav.toggleClass("show ani");
		cross.toggleClass("cross");
	});




});