<?php
	ini_set('display_errors', 0);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="preconnect" href="https://fonts.googleapis.com"> 
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/about.css">
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<title>Driver's assistant</title>
</head>
<body>
	<!-- Header -->
	<header class="header">
		<div class="container">
			<div class="header_inner">
				<div class="header_logo">
					<a class="header_link header_link_logo" href="index.php"><strong>Driver's Assistant</strong></a>
				</div>
				<nav class="header_nav" id="nav">
					<?php if($_COOKIE['login'] == NULL):?>
						<a class="header_link" href="about.php">about us</a>
						<a class="header_link" href="ru/about.php">перевести</a>
					<?php else:?>
						<a class="header_link" href="about.php">about us</a>
						<a class="header_link" href="ru/about.php">перевести</a>
						<a class="header_link" href="account.php"><?= $_COOKIE['login']?></a>
					<?php endif;?>
				</nav>
				<button class="burger" id="showButton">
					<span class="burger_item" id="burgerCross">Menu</span>
				</button>
			</div>
		</div>
	</header>


	<!-- team -->
	<div class="team">
		<div class="container">
			<h4 class="team_title">our team</h4>
			<div class="team_inner">
				<div class="team_block">
					<div class="team_photo1"></div>
					<div class="team_content">
						<a class="team_name" href="#">Demian Tarasov</a>

						<h4 class="team_text">I am from Izhevka and I am 13 years old. I am the programmer of this project.</h4>
					</div>
				</div>
				<div class="team_block">
					<div class="team_photo2"></div>
					<div class="team_content">
						<a class="team_name" href="#">Blinov Vladimir</a>

						<h4 class="team_text">I was born in the city of Izhevka and I am 13 years old. I designed the project.</h4>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- about project -->
	<div class="project_slider">
		<div class="container">
			<h4 class="team_title">About project</h4>
			<div class="project_inner">
				<!-- <div class="project_block_left">
					<div class="project_slider_arrow_left"><</div>
				</div> -->
				<div class="project_block_main">
					<ul class="project_slider_list">
    		    	 	<li class="project_slider_element">
    		    	 		<div class="project_photo1"></div>
    		    	 		<div class="project_content">
    		    	 			<div class="project_title">
    		    	 				1 module
    		    	 			</div>
    		    	 			<div class="project_text">
    		    	 				1 module is located on the gas pedal and sends data on the force and frequency of pressing the pedal to the website and to module 2
    		    	 			</div>
    		    	 		</div>
    		    	 	</li>
    		    	 	<li class="project_slider_element">
    		    	 		<div class="project_photo2"></div>
    		    	 		<div class="project_content">
    		    	 			<div class="project_title">
    		    	 				2 module
    		    	 			</div>
    		    	 			<div class="project_text">
    		    	 				2 module keeps track of all data sent by other modules. Processes and notifies about incorrect work of the driver (1 module) and outputs data from the 3rd module.
    		    	 			</div>
    		    	 		</div>
    		    	 	</li>
    		    	 	<li class="project_slider_element">
    		    	 		<div class="project_photo3"></div>
    		    	 		<div class="project_content">
    		    	 			<div class="project_title">
    		    	 				3 module
    		    	 			</div>
    		    	 			<div class="project_text">
    		    	 				3 module is located next to the cargo and monitors its condition. It sends all the data to module 2 and to the website.
    		    	 			</div>
    		    	 		</div>
    		    	 	</li>
    		 		</ul>
				</div>
				<!-- <div class="project_block_right">
					<div class="project_slider_arrow_right">></div>
				</div> -->
				<div class="project_block_left2">
					<div class="project_slider_arrow_left"><</div>
				</div>
				<div class="project_block_right2">
					<div class="project_slider_arrow_right">></div>
				</div>
			</div>
		<!-- 	<div class="project_slider">
    		 	<div class="project_block">
   					<div class="project_slider_arrow_left"><</div>
   				</div>
				<div class="project_block">
    		 		
    		 	</div>
   				<div class="project_block">
    		 		<div class="project_slider_arrow_right">></div>
    		 	</div>
 			</div> -->
 		</div>
 	</div>
	<!-- futer -->
	<footer class="futer">
		<div class="container">
			<div class="futer_inner">
				<div class="futer_block">
					<h4 class="futer_text">
						in team
					</h4>
					
					<p><a class="futer_text_name" href="https://vk.com/krisapip">Demian Tarasov</a></p>
					<p><a class="futer_text_name" href="https://vk.com/id646411951">Blinov Vladimir</a></p>
				</div>
				<div class="futer_block">
					<h4 class="futer_text">
						resources
					</h4>

					<p><a class="futer_text_name" href="https://github.com/DemianTarasov/site">Website</a></p>
					<p><a class="futer_text_name" href="https://vk.com/izhdvores">Our group</a></p>
				</div>
			</div>
		</div>
	</footer>
	<!-- Javascript -->
	<script type="text/javascript" src="js/app.js"></script>
	<script src="js/slider.js"></script>
	<!-- вызов слайдера -->
	<script>new Sim()</script>
</body>
</html>